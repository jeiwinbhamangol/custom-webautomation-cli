# Maestro Studio with JAR Guide

This guide explains how to use Maestro Studio running directly from its executable JAR (`using java -jar`) to connect to an existing Android device, enter inspect mode, and details the features available for both Android and iOS inside the Studio.

## 1. Connecting to an Existing Android Device via JAR

When running Maestro CLI via its jar executable, global flags are passed **before** the `studio` subcommand.

**Command Structure:**
```bash
java -jar <maestro_jar_file>.jar [global-options] studio [studio-options]
```

### Direct Connect using Device ID (UDID)
If you have an existing Android device or emulator running locally, and you know its device ID (found via `adb devices`), you can specify it using the `--device` flag:
```bash
java -jar automation-cli-2.1.0-all.jar --device emulator-5554 studio
```

### Direct Connect using Host and Port (Remote/Local ADB)
If you are passing the connection to a specific remote or customized ADB daemon instance:
```bash
java -jar automation-cli-2.1.0-all.jar --host localhost --port 5037 studio
```

*(Note: If no options are given, Maestro automatically discovers the first running Simulator/Emulator/Physical Device it finds.)*

---

## 2. Using Inspect Mode in Studio

"Inspect Mode" is the primary function of Maestro Studio. When you launch the studio, Maestro starts a local web server (usually at `http://localhost:<random-port>`) and automatically opens it in your browser. 

In this mode, the studio:
1. Takes continuous snapshots and dumps the View Hierarchy of the connected device.
2. Lets you hover over elements on the screen representation to "inspect" them.
3. Provides exact locator queries you can use in your flows, such as `text`, `id`, `resource-id` (Android).

### Android WebView Inspector
If you are testing hybrid apps or WebViews on Android, you can launch the studio with a specialized flag to use Chrome DevTools under the hood for a better WebView hierarchy rendering:

```bash
java -jar automation-cli-2.1.0-all.jar studio --android-webview-hierarchy devtools
```

---

## 3. Detailed Features Available in Maestro Studio

Maestro Studio provides identical workflow paradigms for both **Android** and **iOS**. The functionality is geared toward rapidly building automated UI flows.

### Inspector & Locator Features (Android & iOS)
- **Visual Screen Mirroring:** See a live snapshot of the app's current state on the device.
- **Element Bounding Boxes:** As you move the cursor across the Studio interface, interactive UI elements (buttons, text fields) are highlighted.
- **Hierarchy Attributes:** Click on an element to see its raw attributes:
  - **Android:** `class` (e.g., `android.widget.TextView`), `resource-id`, `text`, `content-desc`, `bounds`, `clickable`.
  - **iOS:** `type` (e.g., `XCUIElementTypeButton`), `identifier`, `label`, `title`, `value`.
- **Optimal Selectors:** Studio analyzes the element and recommends the best semantic selector (e.g., `id: "login_button"` over `text: "Log In"` if ID is available).

### Flow Generation Features
- **Auto-Generating Tap Commands:** Selecting an element automatically generates the YAML `tapOn` directive for that specific component.
- **Exporting Commands (`--command-output`):** You can instruct Studio to save commands you generate directly to a file.
  ```bash
  java -jar automation-cli-2.1.0-all.jar studio --command-output ./my-script.json
  ```
- **Text Input & Key Presses:** Execute `inputText`, `pressKey` (like Enter or Backspace), and `eraseText` commands live through the Studio interface onto the connected device to progress application state without leaving the browser.
- **REPL capabilities:** You can execute commands visually and have them reflect instantly on the emulator/device, allowing you to string together tests quickly.

### iOS Specific Features
- **Team ID Binding:** If you are testing on Real iOS devices using Studio, you can bind your Apple Team ID directly via the Studio command.
  ```bash
  java -jar automation-cli-2.1.0-all.jar studio --apple-team-id XXXXXXXXXX
  ```

### Advanced UI Debugging
- **Layout Insights:** Since Maestro strips non-actionable nested containers from the default hierarchy to prioritize interactions, examining elements in Studio helps developers realize if their UI layouts possess correct accessibility labels (`contentDescription` for Android, `accessibilityLabel` for iOS).
- **Headless Mode Compatibility:** You can instruct Maestro Studio not to automatically open a browser window via `--no-window`, which is useful if running on a remote headless server but connecting to it from your local machine.
