# Maestro Android Device Detection and Connection

This document details the process of how Maestro (specifically via `studio.jar` or CLI) discovers, connects to, and communicates with Android mobile devices automatically. 

## 1. Device Detection Mechanism
Maestro utilizes a dedicated library called **Dadb** (Direct ADB) to interface with Android devices. When launching Maestro Studio without specifying a platform, the session manager invokes a routine to determine if an Android device is accessible.

The detection workflow operates sequentially:
1. **Explicit Port Specification:** If a `port` is explicitly provided, Maestro attempts to establish a direct connection to that port on the specified `host` (defaulting to `localhost`) using `Dadb.create(host, port)`.
2. **Standard ADB Discovery:** If no specific port is provided, `Dadb.discover(host)` is called. This connects to the standard ADB daemon (typically running on port `5037`) and asks it for a list of connected devices. 
3. **Fallback ADB Server:** If standard discovery yields no devices, Maestro falls back to a custom implementation called `AdbServer` operating on port `5038` (`AdbServer.createDadb(adbServerPort = 5038)`).

If Dadb successfully establishes communication via any of these three stages without throwing an exception, Maestro registers the presence of an Android device.

Furthermore, once a device is detected:
* If the instance ID or `deviceId` starts with `"emulator"`, the device is classified as an **Emulator**.
* Otherwise, it is classified as a **Real Device**.

## 2. Available Connection Types for Android

There are two major layers of connections: the **Host-to-ADB layer** and the **Host-to-Driver layer**.

### A. Host-to-ADB Connections
As highlighted in the detection phase, Maestro leverages **Dadb** to create a TCP-based data link between the host machine and the Android ADB daemon or emulator bypassing parts of standard ADB tooling. 

The connections available are:
* **Standard ADB Daemon Socket (Port 5037):** Used by default to discover locally connected physical phones (via USB/Wi-Fi debug) and running Android emulators.
* **Direct Network Socket:** Direct TCP connection to a specific remote or local host and port over the local area network if specified.
* **Secondary Local ADB Server (Port 5038):** A fallback local server used when primary daemon discovery fails.

### B. Host-to-Driver gRPC Communication
Once ADB connection is established, Maestro needs a high-level channel to dictate UI commands (like tapping, scrolling, getting view hierarchies). It achieves this via a client-server architecture using **gRPC**.

1. **Port Forwarding:** Maestro sets up a TCP port forwarder via `dadb.tcpForward(hostPort, hostPort)` linking a local machine port (default: `7001`) to the device's port.
2. **gRPC Channel:** A plaintext `ManagedChannel` is created to communicate via the locally mapped port forwarder.

## 3. How the Connection Works (Step-by-Step Initialization)

When Maestro decides to connect and start the session for the Studio:

1. **Driver App Installation:**
   Maestro first ensures that the Maestro Driver server applications (`maestro-server` and instrumentation APKs) are installed on the target Android device via ADB packet streaming.

2. **Instrumentation Session Startup:**
   Maestro spins up the Android Instrumentation test runner using the ADB shell. It issues an `am instrument` command precisely targeting the `MaestroDriverService` which acts as the gRPC server:
   ```bash
   am instrument -w -m -e debug false \
     -e class 'dev.mobile.maestro.MaestroDriverService#grpcServer' \
     -e port 7001 \
     dev.mobile.maestro.test/androidx.test.runner.AndroidJUnitRunner &
   ```
   *Note: This kicks off the Maestro service in the background on the phone. The `-e port` defines the port the gRPC server listens on.*

3. **Port Forwarding Mapping:**
   A socket forwarder binds the host port (e.g., `7001`) to the Android device's target port where the instrumentation is listening.

4. **Awaiting Launch:**
   The client polls the mapped `tcp:7001` socket waiting for the gRPC server inside the Android device to accept connections. If the connection hits a predefined timeout without successfully polling, a `AndroidDriverTimeoutException` is thrown.

5. **Executing Commands:**
   With the connection established, Maestro Studio executes commands (like taking screenshots, inputting text, generating the `ViewHierarchy`) directly as structured requests through the `MaestroDriverGrpc` stubs.

6. **Cleanup:**
   When the session terminates, the gRPC channel shuts down, the instrumentation session is violently closed via `kill` commands, the port forwarder closes, and (by default) the server APKs are uninstalled.
